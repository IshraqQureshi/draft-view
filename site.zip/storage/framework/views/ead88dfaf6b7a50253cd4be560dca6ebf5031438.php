<header id="header">
    <div class="container">
        <div class="header--wrapper">
            <div class="header--logo">
                <a href="<?php echo e(route('home')); ?>">
                    <img src="/images/logo.svg" alt="<?php echo e($title); ?>">
                </a>
            </div>
            <div class="header--nav">
                <nav>
                    <ul>
                        <li class="<?php echo e($activeLink == 'home' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('home')); ?>">Home</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'our-process' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('our-process')); ?>">Our Process</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'services' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('services')); ?>">Services</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'pricing' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('pricing')); ?>">Pricing</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'about' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('about')); ?>">About</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'reviews' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('reviews')); ?>">Reviews</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'contact' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('contact')); ?>">Contact</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="header--cta">
                <a href="<?php echo e(route('select-package')); ?>" class="btn">Upgrade My Resume</a>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\draft-view\resources\views/layouts/header.blade.php ENDPATH**/ ?>