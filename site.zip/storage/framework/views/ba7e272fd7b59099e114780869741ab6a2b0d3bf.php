<footer id="footer">
    <div class="container">
        <div class="footer--wrapper flex-row">
            <div class="footer--col footer--col-content">
                <div class="footer--logo">
                    <a href="#">
                        <img src="/images/logo.svg" alt="<?php echo e($title); ?>">
                    </a>
                </div>
                <div class="footer--desc">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiuco laboris nisi ut aliquip veniam, quis nostrud exercitation ullamco in voluptate velit.</p>
                </div>
                <div class="footer--social-links">
                    <ul>
                        <li class="facebook--icon">
                            <a href="#">Facebook</a>
                        </li>
                        <li class="twitter--icon">
                            <a href="#">Twitter</a>
                        </li>
                        <li class="instagram--icon">
                            <a href="#">Instagram</a>
                        </li>
                        <li class="youtube--icon">
                            <a href="#">Youtube</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer--col">
                <div class="footer--col-header">
                    <h3>Services</h3>
                </div>
                <div class="footer-col-menu">
                    <ul>
                        <li>
                            <a href="#">Hire Freelancer</a>
                        </li>
                        <li>
                            <a href="#">Resume Writing</a>
                        </li>
                        <li>
                            <a href="#">Resume Editin</a>
                        </li>
                        <li>
                            <a href="#">Resume Help</a>
                        </li>
                        <li>
                            <a href="#">Linkedin Resume</a>
                        </li>
                        <li>
                            <a href="#">Cover Letter</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer--col">
                <div class="footer--col-header">
                    <h3>Information</h3>
                </div>
                <div class="footer-col-menu">
                    <ul>
                        <li>
                            <a href="#">Career Advice</a>
                        </li>
                        <li>
                            <a href="#">Career Hub</a>
                        </li>
                        <li>
                            <a href="#">Resume Builder</a>
                        </li>
                        <li>
                            <a href="#">Question & Answers</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer--col">
                <div class="footer--col-header">
                    <h3>Company</h3>
                </div>
                <div class="footer-col-menu">
                    <ul>
                        <li class="<?php echo e($activeLink == 'about' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('about')); ?>">About</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'faq' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('faq')); ?>">Faq</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'contact' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('contact')); ?>">Contacts</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'privacy-policy' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('privacy-policy')); ?>">Privacy Policy</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'terms-conditions' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('terms-conditions')); ?>">Terms & Conditions</a>
                        </li>
                        <li class="<?php echo e($activeLink == 'refund-policy' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('refund-policy')); ?>">Refund Policy</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\draft-view\resources\views/layouts/footer.blade.php ENDPATH**/ ?>