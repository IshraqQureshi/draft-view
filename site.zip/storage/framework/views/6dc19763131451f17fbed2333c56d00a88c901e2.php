

<?php $__env->startSection('content'); ?>


    <section id="thankyou">
        <div class="container">
            <h1>Thank <span class="highlight">You!</span></h1>
            <p>Your query has been submitted sucessfully, Our agent will contact you soon.</p>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-view\resources\views/thankyou.blade.php ENDPATH**/ ?>