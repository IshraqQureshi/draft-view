

<?php $__env->startSection('content'); ?>


    <section id="thankyou">
        <div class="container">
            <h1>Thank <span class="highlight">You!</span></h1>
            <p>Your payment has been recevied!</p>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-view\resources\views/payment-thankyou.blade.php ENDPATH**/ ?>