

<?php $__env->startSection('content'); ?>

<section id="page--header">
    <div class="container">
        <div class="page--header-heading">
            <h1>Our Customer <span class="highlight">Reviews</span></h1>
        </div>
    </div>
</section>

<section id="reviews">
    <div class="container">
        <div class="flex-row reviews-row">
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="review--box">
                    <?php if($review['review_type'] == 'text'): ?>
                    <div class="review--title">
                        <h2><?php echo e($review['title']); ?></h2>
                    </div>
                    <div class="review--desc">
                        <p><?php echo e($review['review']); ?></p>
                    </div>
                    <?php elseif($review['review_type'] == 'video'): ?>
                    <div class="review--thumbnail">
                        <img src="<?php echo e($review['review_thumbnail']); ?>" alt="Test">
                    </div>
                    <?php endif; ?>
                    <div class="review--meta <?php echo e($review['review_type'] == 'video' ? 'video-meta' : 'text-meta'); ?>">
                        <?php if($review['review_type'] == 'text'): ?>
                        <div class="review--author-img">
                            <img src="/review-authors/jack-brown.png" alt="<?php echo e($review['author']); ?>">
                        </div>
                        <?php elseif($review['review_type'] == 'video'): ?>
                        <div class="review--play" data-video-url="<?php echo e($review['review_url']); ?>">
                            <img src="/images/play-icon.svg" alt="Play Icon">
                        </div>
                        <?php endif; ?>
                        <div class="review--author">
                            <h3><?php echo e($review['author']); ?></h3>
                            <p><?php echo e($review['author_designation']); ?></p>
                            <ul>
                                <?php for($i = 0; $i < $review['rating']; $i++): ?>
                                    <li>
                                        <img src="/images/star-rating.svg" alt="star">
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-view\resources\views/reviews.blade.php ENDPATH**/ ?>