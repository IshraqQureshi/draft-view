

<?php $__env->startSection('content'); ?>

<section id="page--header">
    <div class="container">
        <div class="page--header-heading">
            <h1>Get in <span class="highlight">Touch</span> With Us</h1>
        </div>
    </div>
</section>

<section id="contact--section">
    <div class="container">
        <div class="flex-row contact--row">
            <div class="contact--content">
                <h3>Send us a message</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>
                <div class="contact--form">
                    <form method="post" action="<?php echo e(route('contact-submit')); ?>" novalidate>
                        <?php echo csrf_field(); ?>                        
                        <div class="form--field-row two--field">
                            <div class="form--field">
                                <label for="first_name">First Name <span class="required">*</span></label>
                                <input type="text" name="first_name" required>                                
                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form--field">
                                <label for="last_name">Last Name</label>
                                <input type="text" name="last_name">
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form--field-row two--field">
                            <div class="form--field">
                                <label for="email_address">Email Address <span class="required">*</span></label>
                                <input type="email" name="email_address" required>
                                <?php $__errorArgs = ['email_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form--field">
                                <label for="phone">Phone</label>
                                <input type="text" name="phone" required>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form--field-row one--field">
                            <div class="form--field">
                                <label for="message">Message</label>
                                <textarea name="message"></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form--field-row form--submit-row">
                            <input type="submit" name="submit" value="Send Message">
                        </div>
                    </form>
                </div>
            </div>
            <div class="contact--img">
                <img src="/images/contact-img.png" alt="Contact IMG">
            </div>
        </div>

        <div class="flex-row contact-info-row">
            <div class="contact-info">
                <div class="contact-info--icon">
                    <img src="/images/call-icon.svg" alt="Call">
                </div>
                <div class="contact-info--title">
                    <a href="tel:001-2345-67-89">001-2345-67-89</a>
                </div>
                <div class="contact-info--desc">
                    <p>Monday to Friday, from 8am to 8pm and Saturday, from 8am to 5pm (toll free).</p>
                </div>
            </div>

            <div class="contact-info">
                <div class="contact-info--icon">
                    <img src="/images/mail-icon.svg" alt="Call">
                </div>
                <div class="contact-info--title">
                    <a href="mailto:hello@draftview.com">hello@draftview.com</a>
                </div>
                <div class="contact-info--desc">
                    <p>Do you have any queries or questions? Send us an e-mail and we will reply to you as soon as possible.</p>
                </div>
            </div>

            <div class="contact-info">
                <div class="contact-info--icon">
                    <img src="/images/location-icon.svg" alt="Call">
                </div>
                <div class="contact-info--title">
                    <a href="tel:001-2345-67-89">Newyork</a>
                </div>
                <div class="contact-info--desc">
                    <p>We are located in 3 Rockaway St., New Rochelle, NY 10801</p>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\draft-view\resources\views/contact.blade.php ENDPATH**/ ?>