@extends('layouts.frontend')

@section('content')


    <section id="thankyou">
        <div class="container">
            <h1>Thank <span class="highlight">You!</span></h1>
            <p>Your payment has been recevied!</p>
        </div>
    </section>

@endsection