@extends('layouts.frontend')

@section('content')


    <section id="thankyou">
        <div class="container">
            <h1>Thank <span class="highlight">You!</span></h1>
            <p>Your query has been submitted sucessfully, Our agent will contact you soon.</p>
        </div>
    </section>

@endsection