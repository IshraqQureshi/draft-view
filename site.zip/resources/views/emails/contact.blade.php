<p>Hello <strong><i>{{$mailData->first_name}} {{$mailData->last_name}}</i></strong></p>

<p>Thankyou for contacting Draft View, our agent will get in touch with you.</p>
<br>
<p>Thank You</p>
<p><strong>Draft View Administrator</strong></p>